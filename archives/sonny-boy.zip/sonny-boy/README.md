# 《漂流少年》（Sonny Boy）全 12 集剧情索引

《漂流少年》是夏目真悟执导、MADHOUSE 制作的 2021 年原创动画。暑假期间，36 名初中生连同学校漂入异次元。学生们在不同规则下求生、寻找归途，也逐渐对要去哪里有了各自的答案。全套文档含剧透。

[角色档案](characters.md)收录主要角色与关键配角的能力、关系和剧情转折。下表可跳转到每一集的独立文档，查看剧情摘要、关键线索和资料来源。

## 逐集剧情

| 集数 | 中文标题 | 本集焦点 |
| --- | --- | --- |
| 01 | [夏日尽头的岛屿](episodes/01.md) | 校园漂入虚空，希在黑暗中看见一束光。 |
| 02 | [外星人](episodes/02.md) | 岛上出现蓝色火焰，瑞穗被卷入纵火疑云。 |
| 03 | [穿木屐的猫](episodes/03.md) | 瑞穗和长良调查失踪学生，希听说明星能听见一个声音。 |
| 04 | [大猩猩棒球](episodes/04.md) | 长良发现自己能跨越世界，并为看见猴子棒球联赛重拿球棒。 |
| 05 | [飞起来的教室](episodes/05.md) | 亚希老师出现，同学开始怀疑长良引发了漂流。 |
| 06 | [久别](episodes/06.md) | 胶片记录着长良所见的世界，众人试着借此回家。 |
| 07 | [道路指南](episodes/07.md) | 同学分头行动，长良在巴别塔遇见两颗星。 |
| 08 | [微笑的狗](episodes/08.md) | 山彦讲述自己变成狗之前，在庆典之村与小玉的往事。 |
| 09 | [这碗鲑鱼茶泡饭 没放鲑鱼喵](episodes/09.md) | 雪原上的双胞胎反复倒转世界，三只猫的秘密逐渐浮现。 |
| 10 | [夏日和修罗](episodes/10.md) | 骨折回想朝风与希的同行，瑞穗和长良用实验探查三只猫的能力。 |
| 11 | [少年和海](episodes/11.md) | 长良和瑞穗告别希，着手完成返回计划。 |
| 12 | [2 年的休假](episodes/12.md) | 长良和瑞穗回到熟悉的日常，漂流改变了他们面对日常的方式。 |

## 资料来源

- [松竹动画官网作品介绍](https://sh-anime.shochiku.co.jp/sonny-boy/introduction.html)
- [松竹动画官网全 12 集剧情介绍](https://sh-anime.shochiku.co.jp/sonny-boy/story.html)
- [松竹动画官网角色介绍](https://sh-anime.shochiku.co.jp/sonny-boy/character.html)
- [MyVideo 中文分集标题](https://www.myvideo.net.tw/details/1/16937)
- [Febri 夏目真悟导演第 1–6 集评注](https://febri.jp/topics/sonnyboy1/)
- [Febri 夏目真悟导演第 7–11 集评注](https://febri.jp/topics/sonnyboy2/)
- [MANTANWEB 夏目真悟导演结局访谈](https://mantan-web.jp/article/20211002dog00m200026000c.html)
